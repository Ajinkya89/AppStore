package com.ak.userstore;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.bachors.wordtospan.*;
import com.blogspot.atifsoftwares.animatoolib.*;
import com.github.angads25.filepicker.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import java.io.*;
import java.text.*;
import java.text.DecimalFormat;
import java.util.*;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class UpdateActivity extends AppCompatActivity {
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private String this_version = "";
	private HashMap<String, Object> insert = new HashMap<>();
	private String returnSize = "";
	private HashMap<String, Object> size = new HashMap<>();
	
	private LinearLayout linear1;
	private ImageView imageview1;
	private TextView textview1;
	private TextView textview2;
	private LinearLayout linear2;
	private Button button1;
	private TextView textview5;
	private Button button2;
	private TextView textview3;
	private TextView textview4;
	
	private DatabaseReference ver = _firebase.getReference("Inapp/version");
	private ChildEventListener _ver_child_listener;
	private Intent update = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.update);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		imageview1 = findViewById(R.id.imageview1);
		textview1 = findViewById(R.id.textview1);
		textview2 = findViewById(R.id.textview2);
		linear2 = findViewById(R.id.linear2);
		button1 = findViewById(R.id.button1);
		textview5 = findViewById(R.id.textview5);
		button2 = findViewById(R.id.button2);
		textview3 = findViewById(R.id.textview3);
		textview4 = findViewById(R.id.textview4);
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				update.setClass(getApplicationContext(), DownloadingUpdateActivity.class);
				startActivity(update);
			}
		});
		
		textview5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				update.setClass(getApplicationContext(), HomeActivity.class);
				startActivity(update);
			}
		});
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		_ver_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (Double.parseDouble(this_version) < Double.parseDouble(_childValue.get("v").toString())) {
					if (_childKey.equals("app")) {
						button1.setOnClickListener(new View.OnClickListener() {
							@Override
							public void onClick(View _view) {
								update.setClass(getApplicationContext(), DownloadingUpdateActivity.class);
								update.putExtra("url", _childValue.get("url").toString());
								startActivity(update);
							}
						});
					}
					if (_childValue.containsKey("whatsnew")) {
						textview2.setText(_childValue.get("whatsnew").toString());
					}
					if (_childValue.containsKey("size")) {
						textview4.setText(_childValue.get("size").toString());
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		ver.addChildEventListener(_ver_child_listener);
	}
	
	private void initializeLogic() {
		this_version = "1.1";
		textview1.setVisibility(View.VISIBLE);
		textview2.setVisibility(View.VISIBLE);
		textview3.setVisibility(View.VISIBLE);
		textview4.setVisibility(View.VISIBLE);
		textview5.setVisibility(View.VISIBLE);
		button1.setVisibility(View.VISIBLE);
	}
	
	public void _SetRadiusToView(final View _view, final double _radius, final String _Colour) {
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable(); gd.setColor(Color.parseColor(_Colour)); gd.setCornerRadius((int)_radius); _view.setBackground(gd);
	}
	
	
	public void _install() {
		String _apk = "update.apk";
		String PATH = Environment.getExternalStorageDirectory() + _apk; java.io.File file = new java.io.File(PATH); if(file.exists()) { 	 Intent intent = new Intent(Intent.ACTION_VIEW); 	 intent.setDataAndType(uriFromFile(getApplicationContext(), new java.io.File(PATH)), "application/vnd.android.package-archive"); 	 intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); 	 intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION); 	 try { 		 getApplicationContext().startActivity(intent); 		 } catch (ActivityNotFoundException e) { 		 e.printStackTrace(); 		 Log.e("TAG", "Error in opening the file!"); 		 } 	 }else{ 	 Toast.makeText(getApplicationContext(),"installing",Toast.LENGTH_LONG).show(); 	 } } Uri uriFromFile(Context context, java.io.File file) { if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) { 	 return androidx.core.content.FileProvider.getUriForFile(context,context.getApplicationContext().getPackageName() + ".provider", file); 	 } else { 	 return Uri.fromFile(file); 	 }
	}
	
	
	public void _convertSize(final double _size) {
		if (_size < 1000) {
			returnSize = String.valueOf((long)(_size)).concat(" B");
		}
		else {
			if (_size < 1000000) {
				returnSize = new DecimalFormat("0.00").format(_size / 1000).concat(" KB");
			}
			else {
				if (_size < 1000000000) {
					returnSize = new DecimalFormat("0.00").format(_size / 1000000).concat(" MB");
				}
				else {
					returnSize = new DecimalFormat("0.00").format(_size / 1000000000).concat(" GB");
				}
			}
		}
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}