package com.ak.userstore;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.bachors.wordtospan.*;
import com.blogspot.atifsoftwares.animatoolib.*;
import com.github.angads25.filepicker.*;
import com.google.firebase.FirebaseApp;
import de.hdodenhof.circleimageview.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

public class AboutActivity extends AppCompatActivity {
	
	private LinearLayout linear1;
	private ScrollView vscroll1;
	private ImageView imageview26;
	private LinearLayout linear2;
	private LinearLayout d1;
	private LinearLayout d3;
	private TextView textview1;
	private LinearLayout linear4;
	private LinearLayout linear37;
	private LinearLayout linear6;
	private LinearLayout linear5;
	private TextView textview19;
	private LinearLayout linear35;
	private LinearLayout linear12;
	private LinearLayout linear19;
	private LinearLayout linear20;
	private CircleImageView circleimageview1;
	private TextView textview2;
	private LinearLayout d2;
	private LinearLayout lik;
	private ImageView imageview1;
	private LinearLayout linear9;
	private TextView textview4;
	private TextView textview5;
	private ImageView imageview14;
	private LinearLayout linear36;
	private TextView textview23;
	private TextView textview24;
	private ImageView imageview3;
	private LinearLayout linear13;
	private TextView textview8;
	private TextView textview9;
	private ImageView imageview8;
	private TextView textview16;
	private ImageView imageview9;
	private TextView textview17;
	private TextView textview25;
	
	private Intent i = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.about);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		vscroll1 = findViewById(R.id.vscroll1);
		imageview26 = findViewById(R.id.imageview26);
		linear2 = findViewById(R.id.linear2);
		d1 = findViewById(R.id.d1);
		d3 = findViewById(R.id.d3);
		textview1 = findViewById(R.id.textview1);
		linear4 = findViewById(R.id.linear4);
		linear37 = findViewById(R.id.linear37);
		linear6 = findViewById(R.id.linear6);
		linear5 = findViewById(R.id.linear5);
		textview19 = findViewById(R.id.textview19);
		linear35 = findViewById(R.id.linear35);
		linear12 = findViewById(R.id.linear12);
		linear19 = findViewById(R.id.linear19);
		linear20 = findViewById(R.id.linear20);
		circleimageview1 = findViewById(R.id.circleimageview1);
		textview2 = findViewById(R.id.textview2);
		d2 = findViewById(R.id.d2);
		lik = findViewById(R.id.lik);
		imageview1 = findViewById(R.id.imageview1);
		linear9 = findViewById(R.id.linear9);
		textview4 = findViewById(R.id.textview4);
		textview5 = findViewById(R.id.textview5);
		imageview14 = findViewById(R.id.imageview14);
		linear36 = findViewById(R.id.linear36);
		textview23 = findViewById(R.id.textview23);
		textview24 = findViewById(R.id.textview24);
		imageview3 = findViewById(R.id.imageview3);
		linear13 = findViewById(R.id.linear13);
		textview8 = findViewById(R.id.textview8);
		textview9 = findViewById(R.id.textview9);
		imageview8 = findViewById(R.id.imageview8);
		textview16 = findViewById(R.id.textview16);
		imageview9 = findViewById(R.id.imageview9);
		textview17 = findViewById(R.id.textview17);
		textview25 = findViewById(R.id.textview25);
		
		imageview26.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
		
		linear12.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setData(Uri.parse("mailto:texttheajinkya@gmail.com"));
				startActivity(i);
			}
		});
		
		linear19.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setAction(Intent.ACTION_VIEW);
				i.setData(Uri.parse("https://t.me/Ajinkya_Dev"));
				startActivity(i);
			}
		});
		
		linear20.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setAction(Intent.ACTION_VIEW);
				i.setData(Uri.parse("https://wa.me/+919665804953?text=Hi"));
				startActivity(i);
			}
		});
	}
	
	private void initializeLogic() {
		_removeScollBar(vscroll1);
		getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
		getWindow().setStatusBarColor(0xFFFFFFFF);
	}
	
	public void _removeScollBar(final View _view) {
		_view.setVerticalScrollBarEnabled(false); _view.setHorizontalScrollBarEnabled(false);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}